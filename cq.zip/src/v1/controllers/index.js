module.exports.users = require('./users')
module.exports.admins = require('./admins')
module.exports.failures = require('./failures')
module.exports.public = require('./public')
