const { sequelize } = require('../../models')

const findAll = (req, res) => {}
const findOne = (req, res) => {}

module.exports = { findAll, findOne }
