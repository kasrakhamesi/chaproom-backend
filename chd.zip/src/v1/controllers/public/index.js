module.exports.contactUs = require('./contactUs.controller')
module.exports.blogs = require('./blogs.contoller')
module.exports.cooperations = require('./cooperations.controller')
module.exports.referrals = require('./referrals.controller')
