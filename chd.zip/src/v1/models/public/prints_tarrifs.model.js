'use strict'
const { Model } = require('sequelize')
module.exports = (sequelize, DataTypes) => {
  class print_tarrifs extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  print_tarrifs.init(
    {
      type: {
        type: DataTypes.ENUM('black_and_white', 'full_color', 'normal_color'),
        allowNull: false
      },
      size: {
        type: DataTypes.ENUM('a4', 'a5', 'a3'),
        allowNull: false
      },
      countOfPages: {
        type: DataTypes.STRING,
        allowNull: false
      },
      single_sided: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
      },
      double_sided: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
      },
      single_sided_glossy: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
      },
      double_sided_glossy: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false
      }
    },
    {
      sequelize,
      modelName: 'print_tarrifs'
    }
  )
  return print_tarrifs
}
