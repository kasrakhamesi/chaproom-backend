module.exports.authorize = require('./authorize.middleware')
module.exports.passport = require('./passport.middleware')
module.exports.permissions = require('./permissions.middleware')